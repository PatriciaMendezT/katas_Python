# KatasPatriciaLaunchX
Ejercicios
